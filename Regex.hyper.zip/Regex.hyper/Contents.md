
# Expresiones regulares - _regex_
:: size: 70
#### Daniel Illescas - github.com/illescasDaniel

:: animate: (1.00;move;left)
### -> Método para encontrar **patrones** en **texto**.

- Texto que **empiece** por una palabra: `key.*`
- Texto que **termine** en algo: `.*\.txt`
- Patrones de caracteres:
  -  `Tengo \d+ años`
    - `Me llamo [a-z]+`
  

*** :: master: title1, background: #00A1D8, size: 90

# Referencia básica

- Letras, números, etc: `abcd 1234`
- Cualquier **dígito**: `\d`, ej.: `6` , `4` ->  `[0-9]`. Inverso: `\D`.
- Cualquier **letra o número**: `\w`, ej.: `a`, `Z`, `4` -> `[a-zA-Z0-9_]`. Inv.: `\W`
- Cualquier letra de cualquier idioma: `\p{L}`
- Cualquier **carácter** (excepto salto línea...): `.`, ej.: `a`, `6`, `&`, `-`, etc.
- **Espacios**, tabulación o nueva línea: `\s` -> `[\r\n\t\f\v ]`.  Inv.: `\S`


:: animate: (0.30;fade), size: 120
![](IMG_0037.PNG.jpg)




*** :: master: regular1 -, background: #FFFFFE

# Referencia básica
- Algún carácter especificado: `[]` Ej.: `[ab5-_%]` -> `5`, `b`, `-`, `a`, `_`, `%`
- Un carácter u otro `|`: `a|b` -> `a`, `b`, `ab`. `(red|blue)` -> `red`, `blue`
- Rango caracteres `[-]`: `[4-9]`, `[f-v]`

:: animate: (0.30;fade), size: 90

![](IMG_0026.PNG.jpg)



*** :: master: regular1, background: #FFFFFE
# Referencia básica - cuantificadores
- 0 o 1 vez `?`:  `abcd?`-> `abcd`, `abc` - `a(100)?` -> `a`, `a100`
- 0 o más `*`: `rápidos*` -> `rápido`, `rápidos`, `rápidossss`
- 1 o más `+`: `rápidos+` -> `rápidos`, `rápidosssssssssssss`
- De n a m veces `{n,m}`: `5{2,4}` -> `55`, `555`, `5555`
- Exactamente n veces `{3}`: `6{3}` -> `666`

:: animate: (0.30;fade)

![](IMG_0028.PNG.jpg)


*** :: master: regular1, background: #FFFFFE
# Validaciones
## Tan específicas como quieras
- Validación correo (básica): `[\w\.]+@\w+\.\w+`



:: animate: (0.30;fade)
![](IMG_0032.PNG.jpg)

:: animate: (0.30;move;left)
https://regexper.com/

:: animate: (0.30;fade)
![website](https://regex101.com/r/VCNpZS/2)


:: animate: (0.30;fade)
https://regex101.com/r/VCNpZS/2

*** :: master: regular1, background: #FFFFFF

# Validaciones
## Tan específicas como quieras

- Validación móvil (básica): `(\+\d{1,3} )?\d{9}`



:: animate: (0.30;fade)
![](IMG_0033.PNG.jpg)


:: animate: (0.30;move;left)
https://www.debuggex.com/

:: animate: (0.30;fade)
![website](https://regex101.com/r/gEm0GK/3)


:: animate: (0.30;fade)
https://regex101.com/r/gEm0GK/3

*** :: master: regular1, background: #FFFFFF

# Validaciones
## Tan específicas como quieras

- Validación correo (avanzada):

:: size: 110, animate: (0.30;fade)
![](IMG_0029.PNG.jpg)
- Validación teléfono (avanzada): `\+(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)\d{1,14}$ `

https://emailregex.com/

*** :: master: regular2
# Avanzado


:: animate: (0.30;fade)
## Validaciones numéricas 


:: animate: (0.30;fade)
![website](https://3widgets.com/)


:: animate: (0.30;fade)
https://3widgets.com/


*** :: master: regular2
# Avanzado
# Capturas - _capture groups_


:: animate: (0.30;move;left)
-> Utilizamos **paréntesis** `( )` para capturar grupos. Sino, `(?: )`.

- Correo capturando el **dominio:** `[\w\.]+@(\w+)\.\w+ `


:: animate: (0.30;fade), size: 90
![](IMG_0035.PNG.jpg)




:: animate: (0.30;fade)
![website](https://regex101.com/r/lfaD5N/1)


:: animate: (0.30;fade)
;; https://regex101.com/r/lfaD5N/1



*** :: master: regular2, size: 100
# Avanzado
## Ejemplos de Sustitución


:: animate: (0.30;fade)
![website](https://regex101.com/r/MDNCbF/1)


:: animate: (0.30;fade)
https://regex101.com/r/MDNCbF/1


*** :: master: regular2
# Avanzado
## Ejemplos de Sustitución


![website](https://regex101.com/r/StMlK7/1)

https://regex101.com/r/StMlK7/1


*** :: master: regular2
# Avanzado
## Ejemplos de Sustitución


![website](https://regex101.com/r/vxFdWI/1)

https://regex101.com/r/vxFdWI/1


*** :: master: regular2
# Avanzado
## Ejemplos de Sustitución


![website](https://regex101.com/r/AGHu9X/1)

https://regex101.com/r/AGHu9X/1


*** :: master: regular2
# Avanzado
## Ejemplos en código
``` kt
val basicEmailRegex = Regex("""[\w\.]+@\w+\.\w+""")❶

val textWithEmail = "send email at: daniel@mail.com"❷
val email = "daniel@mail.com"❷

basicEmailRegex.containsMatchIn(textWithEmail)❸
basicEmailRegex.containsMatchIn(email)❸

basicEmailRegex.matches(textWithEmail)❹
basicEmailRegex.matches(email)❹
```


:: animate: (0.30;fade)
![website](https://pl.kotl.in/t2rJNLt_L)



*** :: master: code
# Avanzado
## Extraer coincidencias en código

``` kt
val textWithEmail = "send email at: daniel@mail.com or dan@pm.me"❶
val textWithEmailMatchResult1 = basicEmailRegex.find(textWithEmail)❷
textWithEmailMatchResult1?.value❸
textWithEmailMatchResult1?.range❸

val textWithEmailMatches = basicEmailRegex.findAll(textWithEmail)❹
for (matchResult in textWithEmailMatches) { /*...*/ }❹

val emailMatchResult2 = basicEmailRegex.matchEntire(email)❺
```

:: animate: (0.30;fade)
![website](https://pl.kotl.in/6EqW4MQYy)

*** :: master: code
# Avanzado
# _Capture groups_

``` kt
val basicEmailRegex = Regex("""([\w\.]+)@(\w+\.\w+)""")❶
val textWithEmail = "send email at: daniel@gmail.com or dan@outlook.com"❷
val textWithEmailMatches = basicEmailRegex.findAll(textWithEmail)❸
for (match in textWithEmailMatches) {❸
    match.groupValues // list❹
    for (matchGroup in match.groups) {❺
        matchGroup?.value❻
        matchGroup?.range❻
    }❺
}❸
```


:: animate: (0.30;fade)
![website](https://pl.kotl.in/XPaHpSvD8)

*** :: master: code
# Avanzado
# Reemplazar coincidencias

``` kt
val telephoneRegex = Regex("""(?:(\+\d{1,3}) )?(\d{9})""")❶
val phonesText = """❷
555666777❷
+34 888999555❷
abcde❷
+1 003335553❷
666666555❷
"""❷
val output: String = phonesText.replace(telephoneRegex, """phone: ($1) $2""")❸
```


:: animate: (0.30;fade)
![website](https://pl.kotl.in/q8klfgpx0)

*** :: master: code
# Avanzado
# Reemplazar coincidencias

``` kt
val output: String = phonesText.replace(telephoneRegex) { match: MatchResult ->❶
    val groupValues = match.groupValues❷
    val prefix = groupValues[1]❸
    val phone = groupValues[2]❸
    return@replace if (prefix.isEmpty()) {❹
        "phone: ${phone}"❺
    } else {❹
        "phone: (${prefix}) ${phone}"❻
    }❹
}❶
```


:: animate: (0.30;fade)
![website](https://pl.kotl.in/Vhq_LOkJy)

*** :: master: code
# Referencia oficial
![website](https://www.regular-expressions.info/reference.html)

https://www.regular-expressions.info/reference.html

*** :: master: regular1
# FIN

![website](https://github.com/illescasDaniel)

*** :: master: regular1
